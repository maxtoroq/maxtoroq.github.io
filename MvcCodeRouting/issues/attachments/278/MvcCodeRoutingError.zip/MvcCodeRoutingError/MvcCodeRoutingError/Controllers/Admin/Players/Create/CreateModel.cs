﻿using System.ComponentModel.DataAnnotations;

namespace MvcCodeRoutingError.Controllers.Admin.Players.Create
{
	public class CreateModel
	{
		public CreateModel()
		{
			Form = new CreateForm();
		}

		public string SomeDisplayProp { get; set; }
		public CreateForm Form { get; set; }
	}

	public class CreateForm
	{
		[Required]
		public string SomeFormData { get; set; }
	}
}