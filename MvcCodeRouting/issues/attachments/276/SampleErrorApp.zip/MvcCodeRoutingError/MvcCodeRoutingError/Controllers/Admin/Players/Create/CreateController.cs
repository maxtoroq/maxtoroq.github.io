﻿using System.Web.Mvc;

namespace MvcCodeRoutingError.Controllers.Admin.Players.Create
{
	public class CreateController : Controller
	{
		public ActionResult Index()
		{
			var model = new CreateModel {SomeDisplayProp = "Test"};
			return View("Create", model);
		}

		[HttpPost]
		public ActionResult Submit([Bind(Prefix = "Form")] CreateForm form)
		{
			if (!ModelState.IsValid)
				return RedirectToAction("Index");

			return Content("Submitted!");
		}

	}
}
