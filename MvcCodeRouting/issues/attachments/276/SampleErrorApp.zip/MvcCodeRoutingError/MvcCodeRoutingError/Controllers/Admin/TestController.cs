﻿using System.Web.Mvc;
using MvcCodeRouting;

namespace MvcCodeRoutingError.Controllers.Admin
{
    public class TestController : Controller
    {
        public ActionResult Index()
        {
            return View("Test");
        }

		[HttpPost]
		public ActionResult Submit(bool formData)
		{
			return Content("Submitted!");
		}

		public ActionResult AnotherAction()
		{
			return Content("Another Action!");
		}

    }
}
