﻿using System.Web.Mvc;

namespace MvcCodeRoutingError.Controllers.SubArea
{
    public class ChildController : Controller
    {
		[ChildActionOnly]
        public ActionResult Index()
        {
            return Content("I am text from the child controller!");
        }

    }
}
