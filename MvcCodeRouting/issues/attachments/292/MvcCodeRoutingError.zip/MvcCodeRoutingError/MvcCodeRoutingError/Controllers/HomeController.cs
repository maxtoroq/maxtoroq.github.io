﻿using System.Web.Mvc;
using MvcCodeRouting;

namespace MvcCodeRoutingError.Controllers
{
	public class HomeController : Controller
	{
		[RequireRouteParameters]
		public ActionResult Index([FromRoute] int someParam)
		{
			ViewBag.Message = "This text was rendered from the action with the 'someParam' parameter.";

			return View();
		}

		[RequireRouteParameters]
		public ActionResult Index()
		{
			ViewBag.Message = "This text was rendered from the action with no parameters.";

			return View();
		}

		public ActionResult About()
		{
			return View();
		}
	}
}
